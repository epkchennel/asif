<html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"/>
<title><?php echo $_GET["n"]; ?> wishing you very happy New year 2018.</title>
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo $_GET["n"]; ?> Wishing you very happy new year 2018." />
    <meta property="og:url" content="" />
    <meta property="og:description" content="HAPPY NEW YEAR 2018 !" />
    <meta property="og:site_name" content="Create Indian Wishes" />
    <meta property="og:image" content="http://wapkaimage.com/702373/702373160_dea0c6287f.png">
<SCRIPT language=JavaScript>





var message = "Sorry ! You have no Permission to  Do This. If You want To buy Any Types Of Script Contact 6350080256";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;

</SCRIPT>
<script>
    /*function check(e)
    {
    alert(e.keyCode);
    }*/
    document.onkeydown = function(e) {
            if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {//Alt+c, Alt+v will also be disabled sadly.
                alert('Bhai Aap Pareshaan Kyun Ho rhe Ho ?? HAHAHAH Buy Kar Lo Script Nhi to Being Blogger Youtube Channel Par jao Sare Script Free Of Cost Milenge.');
            }
            return false;
    };
    </script>
    <link type="text/css" rel="stylesheet" href="http://magic-wish.com/25/hoped.min.css" media="screen,projection"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
<style>
input[type=name], select {
    width: 100%;
    padding: 12px 20px;
    margin: 4px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
.footerbtn {
  border-radius: 5px;
  box-sizing: border-box;
  padding: 5px;
  position: fixed;
  left:0px;
  bottom:0px;
  height:40px;
  width:100%;
  background:#34af23;
  color: #ffffff;
  font-size: 20px;
  text-align: center;
  text-decoration: none;
}

.footerbtn:hover {
  text-decoration: none;
    position: fixed;
}
@-webkit-keyframes jello {  from, 11.1%, to {    transform: none;  }
  22.2% {    transform: skewX(-12.5deg) skewY(-12.5deg);  }
  33.3% {    transform: skewX(6.25deg) skewY(6.25deg);  }
  44.4% {    transform: skewX(-3.125deg) skewY(-3.125deg);  }
  55.5% {    transform: skewX(1.5625deg) skewY(1.5625deg);  }
  66.6% {    transform: skewX(-0.78125deg) skewY(-0.78125deg);  }
  77.7% {    transform: skewX(0.390625deg) skewY(0.390625deg);  }
  88.8% {    transform: skewX(-0.1953125deg) skewY(-0.1953125deg);  }}
.jello {  -webkit-animation: jello 3s infinite;  transform-origin: center; -webkit-animation-delay:6s}
@-webkit-keyframes hue {
  from {    -webkit-filter: hue-rotate(0deg);  }
  to {    -webkit-filter: hue-rotate(-360deg);  }}
    .m1{position:fixed;left:1%; width:auto;height:100%;top:1%;color:#000;}
    .m2{position:fixed;right:1%; width:auto;height:100%;top:1%;color:#000;}
</style>

</head>

<body class="bg" id="beingblogger">
<marquee class="m1" behavior="scroll" direction="up" scrolldelay="5">  <br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/>
</marquee>
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="5"><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/><br><br>
<img src="dandiya.png" height="40px" width="15px"/>
</marquee>

<center>
 <!-- replace it -->
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- wishyou300X50 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:50px"
     data-ad-client="ca-pub-2177839933770182"
     data-ad-slot="7897482221"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
 <!-- replace it -->
</center>   
<main id="beingblogger">
 
<div class="">
<div class="container">
<div class="col-lg-12 col-sm-12 s12">
<div class="row">
<p class="center no-margin">
</p>
<div class="col-lg-12 s12 l6 offset-l3">
<div class="card blue-grey darken-1 hoverable" id="bg-pic">
<div class="card-content white-text">
<p id="animated-example" class="animated pulse card-title center-align name head"><?php echo str_replace("_"," ",$_GET["n"]); ?></p>
<p class="card-title center-align comic wishesed">
<span class="deep-orange-text text-darken-2">W</span>
<span class="green-text text-accent-4">i</span>
<span class="blue-text text-lighten-1">s</span>
<span class=" teal-text text-accent-3">h</span>
<span class="red-text text-accent-3">i</span>
<span class="lime-text">n</span>
<span class="orange-text text-accent-3">g &nbsp;</span>
<span class="lime-text">Y</span>
<span class=" blue-text text-darken-1">o</span>
<span class="lime-text text-accent-3">u</span></p>
<p class="center">
<h2 class="diwali jello"></h2>
<a href=""><img class="diwali jello" style="margin: 0 auto;display: block;" src="beingblogger.gif" height="300px" width="100%"/><br>
</a>
<center></center>
I like the religion that teaches liberty, equality, and fraternity. Hamara Ek hi religion hai India | Share to Everybody	
Happy Ambedkar Jayanti!!..</p>
<p class="name bdaywish right">-<?php echo $_GET["n"]; ?></p></br>
<center>
<div style="padding: 10px;"class="col-sm-12 ">
<button class="btn btn-danger btn-large">Wish Your Friends</button>
<center>
 <!-- replace it -->
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- wishyou300X50 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:50px"
     data-ad-client="ca-pub-2177839933770182"
     data-ad-slot="7897482221"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
 <!-- replace it -->
</center>   

<form method="get" action="/beingblogger.php" class="form-control">
<input class="form-control" placeholder="Enter Your Name !" name="n">
<input type="submit" class="btn btn-success " value="Create >>">
</form>
</div>

</center>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</main>



<a class="footerbtn" href="whatsapp://send?text=*<?php echo $_GET["n"]; ?> Ne Aapko Sabse Pahle* - http://Madhubanimix.com/beingblogger.php?n=<?php echo str_replace(" ","_",$_GET["n"]); ?> - Click Karke Dekho"><img width="20px" height="20px" src="http://magic-wish.com/wtsp.svg"/> SHARE ON WHATSAPP <img width="20px" height="20px" src="http://magic-wish.com/wtsp.svg"/></a>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="http://magic-wish.com/25/snow.js"></script>
    <script>
      jQuery(document).ready(function(e) {
        jQuery('body').wpSuperSnow({
              flakes: ['http://magic-wish.com/25/rose1.png','http://magic-wish.com/25/rose2.png','http://magic-wish.com/25/rose1.png','http://magic-wish.com/25/rose2.png','http://magic-wish.com/25/rose1.png','http://magic-wish.com/25/rose2.png'],
              totalFlakes: '35',
              zIndex: '999999',
              maxSize: '77',
              maxDuration: '40',
              useFlakeTrans: true
           });
      });
    </script>
<div style="margin:1em;">
</div>
</body></html>
<script src="//Bollywoodichowk.com/hope.min.js?version=1.0&value=Important"></script>
<script>Bollywoodichowk();</script>
</body>
</html>